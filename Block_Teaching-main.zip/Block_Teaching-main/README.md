 <img width="400" alt="image" src="https://github.com/user-attachments/assets/b1941994-9af2-4e1f-bdce-fa71a6458d7c" /> <img width="400" height="300" alt="image" src="https://github.com/user-attachments/assets/344d85bc-b61e-476e-aec7-7c0cac6077aa" />

# ⚠️ DISCLAIMER
This repository contains code for educational and learning purposes only. The code is provided as-is, without any warranty, and is intended to help users understand programming concepts, algorithms, and problem-solving techniques.
# Warning 
 - Do not use this code for unethical or illegal purposes.

 - The author is not responsible for any misuse or issues arising from the use of this code.

 - Always test and review the code carefully before using it in any critical environment.

By using this repository, you acknowledge that you understand and accept these terms.

<img width="220" height="81" alt="image" src="https://github.com/user-attachments/assets/01031430-dfec-4612-80f7-b6e04efca0b9" />

